Celtic-Bit Pixel Font
Font designed and created by Mirz (Michelle Lehmann)
=====================================

This package contains 3 fonts. The main Celtic-Bit font which
was created to replicate the brush strokes used in medieval/
calligraphic writing.  The second is Celtic-Bit Thin, which
is simply the same font, but with a more traditional pixel-
font look.  The last font is Celtic-Bitty which is a smaller
condensed version of the font--the difference being that some 
letters have been replaced with more easily-read modern versions 
of the renditions.

This font is best used at 6pt/8px in most graphic programs.

This font may be used for personal and commercial use. 
Commercial use is restricted to incorporation in a project
or design. You may not profit from direct sale/distribution
of this font.  Please see my TOS page at
http://scriptmonkeys.us/monkeys/2010/05/08/graphics-pixel-font-use-license/
for more details. 

The pixel celtic knot border on the preview was created by me. 
It may be used for all uses with credit.

Note that you may re-distribute this font free of charge on
your website. However, please keep all files and names in-tact
and, if possible, please linkback to one of my pages.

More pixel fonts from Mirz can be found at:
http://www.scriptmonkeys.us
http://mirz123.deviantart.com